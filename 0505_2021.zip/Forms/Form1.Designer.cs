﻿
namespace Calculate_Project
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_result = new System.Windows.Forms.TextBox();
            this.button_7 = new System.Windows.Forms.Button();
            this.button_4 = new System.Windows.Forms.Button();
            this.button_1 = new System.Windows.Forms.Button();
            this.button_2 = new System.Windows.Forms.Button();
            this.button_5 = new System.Windows.Forms.Button();
            this.button_8 = new System.Windows.Forms.Button();
            this.button_3 = new System.Windows.Forms.Button();
            this.button_6 = new System.Windows.Forms.Button();
            this.button_9 = new System.Windows.Forms.Button();
            this.button_ABS = new System.Windows.Forms.Button();
            this.button_perm = new System.Windows.Forms.Button();
            this.button_round = new System.Windows.Forms.Button();
            this.button_factorial = new System.Windows.Forms.Button();
            this.button_comb = new System.Windows.Forms.Button();
            this.button_minus = new System.Windows.Forms.Button();
            this.button_multiply = new System.Windows.Forms.Button();
            this.button_division = new System.Windows.Forms.Button();
            this.button_equl = new System.Windows.Forms.Button();
            this.button_spot = new System.Windows.Forms.Button();
            this.button_0 = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_Ans = new System.Windows.Forms.Button();
            this.button_e = new System.Windows.Forms.Button();
            this.button_pi = new System.Windows.Forms.Button();
            this.button_tan = new System.Windows.Forms.Button();
            this.button_cos = new System.Windows.Forms.Button();
            this.button_sin = new System.Windows.Forms.Button();
            this.button_atan = new System.Windows.Forms.Button();
            this.button_acos = new System.Windows.Forms.Button();
            this.button_asin = new System.Windows.Forms.Button();
            this.button_sqrt = new System.Windows.Forms.Button();
            this.button_pow = new System.Windows.Forms.Button();
            this.button_exp = new System.Windows.Forms.Button();
            this.button_sqare = new System.Windows.Forms.Button();
            this.button_ln = new System.Windows.Forms.Button();
            this.button_log10 = new System.Windows.Forms.Button();
            this.button_backspace = new System.Windows.Forms.Button();
            this.button_ozTog = new System.Windows.Forms.Button();
            this.button_gTolb = new System.Windows.Forms.Button();
            this.button_lbTog = new System.Windows.Forms.Button();
            this.button_gTooz = new System.Windows.Forms.Button();
            this.button_mToft = new System.Windows.Forms.Button();
            this.button_ftTom = new System.Windows.Forms.Button();
            this.button_mToinch = new System.Windows.Forms.Button();
            this.button_inchTom = new System.Windows.Forms.Button();
            this.button_comma = new System.Windows.Forms.Button();
            this.textBox_timestamp = new System.Windows.Forms.TextBox();
            this.button_sigfig = new System.Windows.Forms.Button();
            this.button_solve = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_result
            // 
            this.textBox_result.Location = new System.Drawing.Point(216, 51);
            this.textBox_result.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_result.Multiline = true;
            this.textBox_result.Name = "textBox_result";
            this.textBox_result.Size = new System.Drawing.Size(452, 114);
            this.textBox_result.TabIndex = 0;
            // 
            // button_7
            // 
            this.button_7.Location = new System.Drawing.Point(34, 304);
            this.button_7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_7.Name = "button_7";
            this.button_7.Size = new System.Drawing.Size(40, 29);
            this.button_7.TabIndex = 1;
            this.button_7.Text = "7";
            this.button_7.UseVisualStyleBackColor = true;
            this.button_7.Click += new System.EventHandler(this.button_7_Click);
            // 
            // button_4
            // 
            this.button_4.Location = new System.Drawing.Point(34, 340);
            this.button_4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_4.Name = "button_4";
            this.button_4.Size = new System.Drawing.Size(40, 29);
            this.button_4.TabIndex = 2;
            this.button_4.Text = "4";
            this.button_4.UseVisualStyleBackColor = true;
            this.button_4.Click += new System.EventHandler(this.button_4_Click);
            // 
            // button_1
            // 
            this.button_1.Location = new System.Drawing.Point(34, 376);
            this.button_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_1.Name = "button_1";
            this.button_1.Size = new System.Drawing.Size(40, 29);
            this.button_1.TabIndex = 3;
            this.button_1.Text = "1";
            this.button_1.UseVisualStyleBackColor = true;
            this.button_1.Click += new System.EventHandler(this.button_1_Click);
            // 
            // button_2
            // 
            this.button_2.Location = new System.Drawing.Point(81, 376);
            this.button_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_2.Name = "button_2";
            this.button_2.Size = new System.Drawing.Size(40, 29);
            this.button_2.TabIndex = 6;
            this.button_2.Text = "2";
            this.button_2.UseVisualStyleBackColor = true;
            this.button_2.Click += new System.EventHandler(this.button_2_Click);
            // 
            // button_5
            // 
            this.button_5.Location = new System.Drawing.Point(81, 340);
            this.button_5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_5.Name = "button_5";
            this.button_5.Size = new System.Drawing.Size(40, 29);
            this.button_5.TabIndex = 5;
            this.button_5.Text = "5";
            this.button_5.UseVisualStyleBackColor = true;
            this.button_5.Click += new System.EventHandler(this.button_5_Click);
            // 
            // button_8
            // 
            this.button_8.Location = new System.Drawing.Point(81, 304);
            this.button_8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_8.Name = "button_8";
            this.button_8.Size = new System.Drawing.Size(40, 29);
            this.button_8.TabIndex = 4;
            this.button_8.Text = "8";
            this.button_8.UseVisualStyleBackColor = true;
            this.button_8.Click += new System.EventHandler(this.button_8_Click);
            // 
            // button_3
            // 
            this.button_3.Location = new System.Drawing.Point(128, 376);
            this.button_3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_3.Name = "button_3";
            this.button_3.Size = new System.Drawing.Size(40, 29);
            this.button_3.TabIndex = 9;
            this.button_3.Text = "3";
            this.button_3.UseVisualStyleBackColor = true;
            this.button_3.Click += new System.EventHandler(this.button_3_Click);
            // 
            // button_6
            // 
            this.button_6.Location = new System.Drawing.Point(128, 340);
            this.button_6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_6.Name = "button_6";
            this.button_6.Size = new System.Drawing.Size(40, 29);
            this.button_6.TabIndex = 8;
            this.button_6.Text = "6";
            this.button_6.UseVisualStyleBackColor = true;
            this.button_6.Click += new System.EventHandler(this.button_6_Click);
            // 
            // button_9
            // 
            this.button_9.Location = new System.Drawing.Point(128, 304);
            this.button_9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_9.Name = "button_9";
            this.button_9.Size = new System.Drawing.Size(40, 29);
            this.button_9.TabIndex = 7;
            this.button_9.Text = "9";
            this.button_9.UseVisualStyleBackColor = true;
            this.button_9.Click += new System.EventHandler(this.button_9_Click);
            // 
            // button_ABS
            // 
            this.button_ABS.Location = new System.Drawing.Point(477, 304);
            this.button_ABS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_ABS.Name = "button_ABS";
            this.button_ABS.Size = new System.Drawing.Size(54, 29);
            this.button_ABS.TabIndex = 17;
            this.button_ABS.Text = "ABS";
            this.button_ABS.UseVisualStyleBackColor = true;
            this.button_ABS.Click += new System.EventHandler(this.button_ABS_Click);
            // 
            // button_perm
            // 
            this.button_perm.Location = new System.Drawing.Point(416, 340);
            this.button_perm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_perm.Name = "button_perm";
            this.button_perm.Size = new System.Drawing.Size(54, 29);
            this.button_perm.TabIndex = 16;
            this.button_perm.Text = "nPr";
            this.button_perm.UseVisualStyleBackColor = true;
            this.button_perm.Click += new System.EventHandler(this.button_perm_Click);
            // 
            // button_round
            // 
            this.button_round.Location = new System.Drawing.Point(477, 340);
            this.button_round.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_round.Name = "button_round";
            this.button_round.Size = new System.Drawing.Size(54, 29);
            this.button_round.TabIndex = 15;
            this.button_round.Text = "Rnd";
            this.button_round.UseVisualStyleBackColor = true;
            this.button_round.Click += new System.EventHandler(this.button_round_Click);
            // 
            // button_factorial
            // 
            this.button_factorial.Location = new System.Drawing.Point(477, 376);
            this.button_factorial.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_factorial.Name = "button_factorial";
            this.button_factorial.Size = new System.Drawing.Size(54, 29);
            this.button_factorial.TabIndex = 14;
            this.button_factorial.Text = "!";
            this.button_factorial.UseVisualStyleBackColor = true;
            this.button_factorial.Click += new System.EventHandler(this.button_factorial_Click);
            // 
            // button_comb
            // 
            this.button_comb.Location = new System.Drawing.Point(416, 304);
            this.button_comb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_comb.Name = "button_comb";
            this.button_comb.Size = new System.Drawing.Size(54, 29);
            this.button_comb.TabIndex = 13;
            this.button_comb.Text = "nCr";
            this.button_comb.UseVisualStyleBackColor = true;
            this.button_comb.Click += new System.EventHandler(this.button_comb_Click);
            // 
            // button_minus
            // 
            this.button_minus.Location = new System.Drawing.Point(175, 376);
            this.button_minus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_minus.Name = "button_minus";
            this.button_minus.Size = new System.Drawing.Size(40, 29);
            this.button_minus.TabIndex = 12;
            this.button_minus.Text = "-";
            this.button_minus.UseVisualStyleBackColor = true;
            this.button_minus.Click += new System.EventHandler(this.button_minus_Click);
            // 
            // button_multiply
            // 
            this.button_multiply.Location = new System.Drawing.Point(175, 340);
            this.button_multiply.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_multiply.Name = "button_multiply";
            this.button_multiply.Size = new System.Drawing.Size(40, 29);
            this.button_multiply.TabIndex = 11;
            this.button_multiply.Text = "*";
            this.button_multiply.UseVisualStyleBackColor = true;
            this.button_multiply.Click += new System.EventHandler(this.button_multiply_Click);
            // 
            // button_division
            // 
            this.button_division.Location = new System.Drawing.Point(175, 304);
            this.button_division.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_division.Name = "button_division";
            this.button_division.Size = new System.Drawing.Size(40, 29);
            this.button_division.TabIndex = 10;
            this.button_division.Text = "/";
            this.button_division.UseVisualStyleBackColor = true;
            this.button_division.Click += new System.EventHandler(this.button_division_Click);
            // 
            // button_equl
            // 
            this.button_equl.Location = new System.Drawing.Point(175, 449);
            this.button_equl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_equl.Name = "button_equl";
            this.button_equl.Size = new System.Drawing.Size(40, 29);
            this.button_equl.TabIndex = 21;
            this.button_equl.Text = "=";
            this.button_equl.UseVisualStyleBackColor = true;
            this.button_equl.Click += new System.EventHandler(this.button_equl_Click);
            // 
            // button_spot
            // 
            this.button_spot.Location = new System.Drawing.Point(34, 412);
            this.button_spot.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_spot.Name = "button_spot";
            this.button_spot.Size = new System.Drawing.Size(40, 29);
            this.button_spot.TabIndex = 20;
            this.button_spot.Text = ".";
            this.button_spot.UseVisualStyleBackColor = true;
            this.button_spot.Click += new System.EventHandler(this.button_spot_Click);
            // 
            // button_0
            // 
            this.button_0.Location = new System.Drawing.Point(81, 412);
            this.button_0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_0.Name = "button_0";
            this.button_0.Size = new System.Drawing.Size(40, 29);
            this.button_0.TabIndex = 19;
            this.button_0.Text = "0";
            this.button_0.UseVisualStyleBackColor = true;
            this.button_0.Click += new System.EventHandler(this.button_0_Click);
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(175, 412);
            this.button_add.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(40, 29);
            this.button_add.TabIndex = 22;
            this.button_add.Text = "+";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(128, 268);
            this.button_clear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(40, 29);
            this.button_clear.TabIndex = 26;
            this.button_clear.Text = "C";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_Ans
            // 
            this.button_Ans.Location = new System.Drawing.Point(128, 449);
            this.button_Ans.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_Ans.Name = "button_Ans";
            this.button_Ans.Size = new System.Drawing.Size(40, 29);
            this.button_Ans.TabIndex = 25;
            this.button_Ans.Text = "Ans";
            this.button_Ans.UseVisualStyleBackColor = true;
            this.button_Ans.Click += new System.EventHandler(this.button_Ans_Click);
            // 
            // button_e
            // 
            this.button_e.Location = new System.Drawing.Point(81, 449);
            this.button_e.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_e.Name = "button_e";
            this.button_e.Size = new System.Drawing.Size(40, 29);
            this.button_e.TabIndex = 24;
            this.button_e.Text = "e";
            this.button_e.UseVisualStyleBackColor = true;
            // 
            // button_pi
            // 
            this.button_pi.Location = new System.Drawing.Point(34, 449);
            this.button_pi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_pi.Name = "button_pi";
            this.button_pi.Size = new System.Drawing.Size(40, 29);
            this.button_pi.TabIndex = 23;
            this.button_pi.Text = "pi";
            this.button_pi.UseVisualStyleBackColor = true;
            // 
            // button_tan
            // 
            this.button_tan.Location = new System.Drawing.Point(222, 376);
            this.button_tan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_tan.Name = "button_tan";
            this.button_tan.Size = new System.Drawing.Size(40, 29);
            this.button_tan.TabIndex = 29;
            this.button_tan.Text = "tan";
            this.button_tan.UseVisualStyleBackColor = true;
            this.button_tan.Click += new System.EventHandler(this.button_tan_Click);
            // 
            // button_cos
            // 
            this.button_cos.Location = new System.Drawing.Point(222, 340);
            this.button_cos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_cos.Name = "button_cos";
            this.button_cos.Size = new System.Drawing.Size(40, 29);
            this.button_cos.TabIndex = 28;
            this.button_cos.Text = "cos";
            this.button_cos.UseVisualStyleBackColor = true;
            this.button_cos.Click += new System.EventHandler(this.button_cos_Click);
            // 
            // button_sin
            // 
            this.button_sin.Location = new System.Drawing.Point(222, 304);
            this.button_sin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_sin.Name = "button_sin";
            this.button_sin.Size = new System.Drawing.Size(40, 29);
            this.button_sin.TabIndex = 27;
            this.button_sin.Text = "sin";
            this.button_sin.UseVisualStyleBackColor = true;
            this.button_sin.Click += new System.EventHandler(this.button_sin_Click);
            // 
            // button_atan
            // 
            this.button_atan.Location = new System.Drawing.Point(269, 376);
            this.button_atan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_atan.Name = "button_atan";
            this.button_atan.Size = new System.Drawing.Size(47, 29);
            this.button_atan.TabIndex = 32;
            this.button_atan.Text = "atan";
            this.button_atan.UseVisualStyleBackColor = true;
            this.button_atan.Click += new System.EventHandler(this.button_atan_Click);
            // 
            // button_acos
            // 
            this.button_acos.Location = new System.Drawing.Point(269, 340);
            this.button_acos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_acos.Name = "button_acos";
            this.button_acos.Size = new System.Drawing.Size(47, 29);
            this.button_acos.TabIndex = 31;
            this.button_acos.Text = "acos";
            this.button_acos.UseVisualStyleBackColor = true;
            this.button_acos.Click += new System.EventHandler(this.button_acos_Click);
            // 
            // button_asin
            // 
            this.button_asin.Location = new System.Drawing.Point(269, 304);
            this.button_asin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_asin.Name = "button_asin";
            this.button_asin.Size = new System.Drawing.Size(47, 29);
            this.button_asin.TabIndex = 30;
            this.button_asin.Text = "asin";
            this.button_asin.UseVisualStyleBackColor = true;
            this.button_asin.Click += new System.EventHandler(this.button_asin_Click);
            // 
            // button_sqrt
            // 
            this.button_sqrt.Location = new System.Drawing.Point(322, 412);
            this.button_sqrt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_sqrt.Name = "button_sqrt";
            this.button_sqrt.Size = new System.Drawing.Size(40, 29);
            this.button_sqrt.TabIndex = 36;
            this.button_sqrt.Text = "sqrt";
            this.button_sqrt.UseVisualStyleBackColor = true;
            this.button_sqrt.Click += new System.EventHandler(this.button_sqrt_Click);
            // 
            // button_pow
            // 
            this.button_pow.Location = new System.Drawing.Point(322, 376);
            this.button_pow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_pow.Name = "button_pow";
            this.button_pow.Size = new System.Drawing.Size(40, 29);
            this.button_pow.TabIndex = 35;
            this.button_pow.Text = "x^y";
            this.button_pow.UseVisualStyleBackColor = true;
            this.button_pow.Click += new System.EventHandler(this.button_pow_Click);
            // 
            // button_exp
            // 
            this.button_exp.Location = new System.Drawing.Point(322, 340);
            this.button_exp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_exp.Name = "button_exp";
            this.button_exp.Size = new System.Drawing.Size(40, 29);
            this.button_exp.TabIndex = 34;
            this.button_exp.Text = "e^x";
            this.button_exp.UseVisualStyleBackColor = true;
            this.button_exp.Click += new System.EventHandler(this.button_exp_Click);
            // 
            // button_sqare
            // 
            this.button_sqare.Location = new System.Drawing.Point(322, 304);
            this.button_sqare.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_sqare.Name = "button_sqare";
            this.button_sqare.Size = new System.Drawing.Size(40, 29);
            this.button_sqare.TabIndex = 33;
            this.button_sqare.Text = "x^2";
            this.button_sqare.UseVisualStyleBackColor = true;
            this.button_sqare.Click += new System.EventHandler(this.button_sqare_Click);
            // 
            // button_ln
            // 
            this.button_ln.Location = new System.Drawing.Point(369, 340);
            this.button_ln.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_ln.Name = "button_ln";
            this.button_ln.Size = new System.Drawing.Size(40, 29);
            this.button_ln.TabIndex = 38;
            this.button_ln.Text = "ln";
            this.button_ln.UseVisualStyleBackColor = true;
            this.button_ln.Click += new System.EventHandler(this.button_ln_Click);
            // 
            // button_log10
            // 
            this.button_log10.Location = new System.Drawing.Point(369, 304);
            this.button_log10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_log10.Name = "button_log10";
            this.button_log10.Size = new System.Drawing.Size(40, 29);
            this.button_log10.TabIndex = 37;
            this.button_log10.Text = "log";
            this.button_log10.UseVisualStyleBackColor = true;
            this.button_log10.Click += new System.EventHandler(this.button_log10_Click);
            // 
            // button_backspace
            // 
            this.button_backspace.Location = new System.Drawing.Point(175, 268);
            this.button_backspace.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_backspace.Name = "button_backspace";
            this.button_backspace.Size = new System.Drawing.Size(40, 29);
            this.button_backspace.TabIndex = 39;
            this.button_backspace.Text = "<-";
            this.button_backspace.UseVisualStyleBackColor = true;
            this.button_backspace.Click += new System.EventHandler(this.button_backspace_Click);
            // 
            // button_ozTog
            // 
            this.button_ozTog.Location = new System.Drawing.Point(597, 376);
            this.button_ozTog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_ozTog.Name = "button_ozTog";
            this.button_ozTog.Size = new System.Drawing.Size(56, 29);
            this.button_ozTog.TabIndex = 42;
            this.button_ozTog.Text = "oz->g";
            this.button_ozTog.UseVisualStyleBackColor = true;
            this.button_ozTog.Click += new System.EventHandler(this.button_ozTog_Click);
            // 
            // button_gTolb
            // 
            this.button_gTolb.Location = new System.Drawing.Point(597, 340);
            this.button_gTolb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_gTolb.Name = "button_gTolb";
            this.button_gTolb.Size = new System.Drawing.Size(56, 29);
            this.button_gTolb.TabIndex = 41;
            this.button_gTolb.Text = "g->lb";
            this.button_gTolb.UseVisualStyleBackColor = true;
            this.button_gTolb.Click += new System.EventHandler(this.button_gTolb_Click);
            // 
            // button_lbTog
            // 
            this.button_lbTog.Location = new System.Drawing.Point(597, 304);
            this.button_lbTog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_lbTog.Name = "button_lbTog";
            this.button_lbTog.Size = new System.Drawing.Size(56, 29);
            this.button_lbTog.TabIndex = 40;
            this.button_lbTog.Text = "lb->g";
            this.button_lbTog.UseVisualStyleBackColor = true;
            this.button_lbTog.Click += new System.EventHandler(this.button_lbTog_Click);
            // 
            // button_gTooz
            // 
            this.button_gTooz.Location = new System.Drawing.Point(597, 412);
            this.button_gTooz.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_gTooz.Name = "button_gTooz";
            this.button_gTooz.Size = new System.Drawing.Size(56, 29);
            this.button_gTooz.TabIndex = 43;
            this.button_gTooz.Text = "g->oz";
            this.button_gTooz.UseVisualStyleBackColor = true;
            this.button_gTooz.Click += new System.EventHandler(this.button_gTooz_Click);
            // 
            // button_mToft
            // 
            this.button_mToft.Location = new System.Drawing.Point(655, 412);
            this.button_mToft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_mToft.Name = "button_mToft";
            this.button_mToft.Size = new System.Drawing.Size(72, 29);
            this.button_mToft.TabIndex = 47;
            this.button_mToft.Text = "m->ft";
            this.button_mToft.UseVisualStyleBackColor = true;
            this.button_mToft.Click += new System.EventHandler(this.button_mToft_Click);
            // 
            // button_ftTom
            // 
            this.button_ftTom.Location = new System.Drawing.Point(655, 376);
            this.button_ftTom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_ftTom.Name = "button_ftTom";
            this.button_ftTom.Size = new System.Drawing.Size(72, 29);
            this.button_ftTom.TabIndex = 46;
            this.button_ftTom.Text = "ft->m";
            this.button_ftTom.UseVisualStyleBackColor = true;
            this.button_ftTom.Click += new System.EventHandler(this.button_ftTom_Click);
            // 
            // button_mToinch
            // 
            this.button_mToinch.Location = new System.Drawing.Point(655, 340);
            this.button_mToinch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_mToinch.Name = "button_mToinch";
            this.button_mToinch.Size = new System.Drawing.Size(72, 29);
            this.button_mToinch.TabIndex = 45;
            this.button_mToinch.Text = "m->inch";
            this.button_mToinch.UseVisualStyleBackColor = true;
            this.button_mToinch.Click += new System.EventHandler(this.button_mToinch_Click);
            // 
            // button_inchTom
            // 
            this.button_inchTom.Location = new System.Drawing.Point(655, 304);
            this.button_inchTom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_inchTom.Name = "button_inchTom";
            this.button_inchTom.Size = new System.Drawing.Size(72, 29);
            this.button_inchTom.TabIndex = 44;
            this.button_inchTom.Text = "inch->m";
            this.button_inchTom.UseVisualStyleBackColor = true;
            this.button_inchTom.Click += new System.EventHandler(this.button_inchTom_Click);
            // 
            // button_comma
            // 
            this.button_comma.Location = new System.Drawing.Point(128, 412);
            this.button_comma.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_comma.Name = "button_comma";
            this.button_comma.Size = new System.Drawing.Size(40, 29);
            this.button_comma.TabIndex = 48;
            this.button_comma.Text = ",";
            this.button_comma.UseVisualStyleBackColor = true;
            this.button_comma.Click += new System.EventHandler(this.button_comma_Click);
            // 
            // textBox_timestamp
            // 
            this.textBox_timestamp.Location = new System.Drawing.Point(216, 172);
            this.textBox_timestamp.Multiline = true;
            this.textBox_timestamp.Name = "textBox_timestamp";
            this.textBox_timestamp.Size = new System.Drawing.Size(452, 68);
            this.textBox_timestamp.TabIndex = 49;
            // 
            // button_sigfig
            // 
            this.button_sigfig.Location = new System.Drawing.Point(369, 376);
            this.button_sigfig.Name = "button_sigfig";
            this.button_sigfig.Size = new System.Drawing.Size(75, 23);
            this.button_sigfig.TabIndex = 50;
            this.button_sigfig.Text = "유효숫자";
            this.button_sigfig.UseVisualStyleBackColor = true;
            this.button_sigfig.Click += new System.EventHandler(this.button_sigfig_Click);
            // 
            // button_solve
            // 
            this.button_solve.Location = new System.Drawing.Point(81, 268);
            this.button_solve.Name = "button_solve";
            this.button_solve.Size = new System.Drawing.Size(41, 29);
            this.button_solve.TabIndex = 51;
            this.button_solve.Text = "solve";
            this.button_solve.UseVisualStyleBackColor = true;
            this.button_solve.Click += new System.EventHandler(this.button_solve_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 562);
            this.Controls.Add(this.button_solve);
            this.Controls.Add(this.button_sigfig);
            this.Controls.Add(this.textBox_timestamp);
            this.Controls.Add(this.button_comma);
            this.Controls.Add(this.button_mToft);
            this.Controls.Add(this.button_ftTom);
            this.Controls.Add(this.button_mToinch);
            this.Controls.Add(this.button_inchTom);
            this.Controls.Add(this.button_gTooz);
            this.Controls.Add(this.button_ozTog);
            this.Controls.Add(this.button_gTolb);
            this.Controls.Add(this.button_lbTog);
            this.Controls.Add(this.button_backspace);
            this.Controls.Add(this.button_ln);
            this.Controls.Add(this.button_log10);
            this.Controls.Add(this.button_sqrt);
            this.Controls.Add(this.button_pow);
            this.Controls.Add(this.button_exp);
            this.Controls.Add(this.button_sqare);
            this.Controls.Add(this.button_atan);
            this.Controls.Add(this.button_acos);
            this.Controls.Add(this.button_asin);
            this.Controls.Add(this.button_tan);
            this.Controls.Add(this.button_cos);
            this.Controls.Add(this.button_sin);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_Ans);
            this.Controls.Add(this.button_e);
            this.Controls.Add(this.button_pi);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.button_equl);
            this.Controls.Add(this.button_spot);
            this.Controls.Add(this.button_0);
            this.Controls.Add(this.button_ABS);
            this.Controls.Add(this.button_perm);
            this.Controls.Add(this.button_round);
            this.Controls.Add(this.button_factorial);
            this.Controls.Add(this.button_comb);
            this.Controls.Add(this.button_minus);
            this.Controls.Add(this.button_multiply);
            this.Controls.Add(this.button_division);
            this.Controls.Add(this.button_3);
            this.Controls.Add(this.button_6);
            this.Controls.Add(this.button_9);
            this.Controls.Add(this.button_2);
            this.Controls.Add(this.button_5);
            this.Controls.Add(this.button_8);
            this.Controls.Add(this.button_1);
            this.Controls.Add(this.button_4);
            this.Controls.Add(this.button_7);
            this.Controls.Add(this.textBox_result);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_result;
        private System.Windows.Forms.Button button_7;
        private System.Windows.Forms.Button button_4;
        private System.Windows.Forms.Button button_1;
        private System.Windows.Forms.Button button_2;
        private System.Windows.Forms.Button button_5;
        private System.Windows.Forms.Button button_8;
        private System.Windows.Forms.Button button_3;
        private System.Windows.Forms.Button button_6;
        private System.Windows.Forms.Button button_9;
        private System.Windows.Forms.Button button_ABS;
        private System.Windows.Forms.Button button_perm;
        private System.Windows.Forms.Button button_round;
        private System.Windows.Forms.Button button_factorial;
        private System.Windows.Forms.Button button_comb;
        private System.Windows.Forms.Button button_minus;
        private System.Windows.Forms.Button button_multiply;
        private System.Windows.Forms.Button button_division;
        private System.Windows.Forms.Button button_equl;
        private System.Windows.Forms.Button button_spot;
        private System.Windows.Forms.Button button_0;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_Ans;
        private System.Windows.Forms.Button button_e;
        private System.Windows.Forms.Button button_pi;
        private System.Windows.Forms.Button button_tan;
        private System.Windows.Forms.Button button_cos;
        private System.Windows.Forms.Button button_sin;
        private System.Windows.Forms.Button button_atan;
        private System.Windows.Forms.Button button_acos;
        private System.Windows.Forms.Button button_asin;
        private System.Windows.Forms.Button button_sqrt;
        private System.Windows.Forms.Button button_pow;
        private System.Windows.Forms.Button button_exp;
        private System.Windows.Forms.Button button_sqare;
        private System.Windows.Forms.Button button_ln;
        private System.Windows.Forms.Button button_log10;
        private System.Windows.Forms.Button button_backspace;
        private System.Windows.Forms.Button button_ozTog;
        private System.Windows.Forms.Button button_gTolb;
        private System.Windows.Forms.Button button_lbTog;
        private System.Windows.Forms.Button button_gTooz;
        private System.Windows.Forms.Button button_mToft;
        private System.Windows.Forms.Button button_ftTom;
        private System.Windows.Forms.Button button_mToinch;
        private System.Windows.Forms.Button button_inchTom;
        private System.Windows.Forms.Button button_comma;
        private System.Windows.Forms.TextBox textBox_timestamp;
        private System.Windows.Forms.Button button_sigfig;
        private System.Windows.Forms.Button button_solve;
    }
}

