﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculate_Project.CalMath
{
    public class Constants
    {
        public double GetPi()
        {
            return Math.PI;
        }

        public double GetE()
        {
            return Math.E;
        }
    }
}
