﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculate_Project.additoinal_function
{
    internal class time
    {
            public static void timelog()
           {
               
           }
       

   }
}
