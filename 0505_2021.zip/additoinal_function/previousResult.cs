﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculate_Project.additoinal_function
{
    public static class previousResult
    {
        public static double LastAnswer { get; set; } = 0;
        // answer 등호 버튼에 해당 기능을 추가하여 결과를 Ans에 저장
        // answer.Ans.LastAnswer = result;
    }

}
